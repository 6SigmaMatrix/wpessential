<?php
return [
	'id'          => 'header_panel',
	'title'       => __( 'Header Settings', 'wpessential' ),
	'description' => __( '', 'wpessential' ),
	'priority'    => 50,
];
