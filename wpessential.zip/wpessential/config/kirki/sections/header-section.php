<?php
return [
	[
		'id'          => 'header_section',
		'title'       => __( 'Header Settings', 'wpessential' ),
		'description' => __( '', 'wpessential' ),
		'panel'       => 'header_panel',
		'priority'    => 10,
	]
];
