<?php

namespace WPEssential\Plugins\Panel;

if ( ! \defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

abstract class Common
{
}
