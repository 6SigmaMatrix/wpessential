<?php

namespace WPEssential\Plugins\Builders\Fields\Helper\Editor;

if ( ! \defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

trait Beaver
{
}
