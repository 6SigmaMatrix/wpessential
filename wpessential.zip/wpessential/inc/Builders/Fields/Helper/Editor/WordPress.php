<?php

namespace WPEssential\Plugins\Builders\Fields\Helper\Editor;

if ( ! \defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

trait WordPress
{
	/**
	 * Prepare the wordpress fields.
	 *
	 * @return array
	 */
	public function wordpress ()
	{
		return [];
	}
}
