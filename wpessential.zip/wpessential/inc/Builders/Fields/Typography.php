<?php

namespace WPEssential\Plugins\Builders\Fields;

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use function defined;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Typography extends Field
{

	public function __construct ( string $key = '', string $selector = '' )
	{
		parent::__construct( $key, $selector );
		$this->common_key = $key;
	}

	public function typography ()
	{
		return [
			$this->color()->selector( $this->wrap_selector ),
			$this->family()->selector( $this->wrap_selector ),
			$this->size()->selector( $this->wrap_selector ),
			$this->weight()->selector( $this->wrap_selector ),
			$this->kerning()->selector( $this->wrap_selector ),
			$this->variant_cps()->selector( $this->wrap_selector ),
			$this->transform()->selector( $this->wrap_selector ),
			$this->decoration()->selector( $this->wrap_selector ),
			$this->line_height()->selector( $this->wrap_selector ),
			$this->letter_spacing()->selector( $this->wrap_selector ),
			$this->word_spacing()->selector( $this->wrap_selector ),
			$this->text_stroke()->selector( $this->wrap_selector ),
			$this->text_stroke_color()->selector( $this->wrap_selector ),
			$this->text_shadow()->selector( $this->wrap_selector ),
			$this->blend_mode()->selector( $this->wrap_selector ),
		];
	}

	public function color ()
	{
		return Color::make( __( 'Text Color' ), "common_{$this->common_key}_font_color" )
		            ->global( [ 'default' => Global_Colors::COLOR_PRIMARY ] );
	}

	public function family ()
	{
		return FontFamily::make( __( 'Family' ), "common_{$this->common_key}_font_family" )
		                 ->global( [ 'default' => Global_Typography::TYPOGRAPHY_PRIMARY ] )
		                 ->selector_value( 'font-family: "{{VALUE}}" Sans-serif;' )
		                 ->label_block( true );
	}

	public static function make ( ...$arguments )
	{
		return new static( ...$arguments );
	}

	public function size ()
	{
		return Slider::make( __( 'Size' ), "common_{$this->common_key}_font_size" )
		             ->size_unit( array_keys( wpe_style_unites() ) )
		             ->range( [
			             'px' => [
				             'min' => 1,
			             ],
			             'vw' => [
				             'min' => 0.1
			             ],
		             ] )
		             ->selector_value( 'font-size: {{SIZE}}{{UNIT}}' )
		             ->responsive( true );
	}

	public function kerning ()
	{
		return Select::make( __( 'Kerning' ), "common_{$this->common_key}_font_kerning" )
		             ->options( wpe_font_kerning() )
		             ->responsive( true )
		             ->label_block( true );
	}

	public function variant_cps ()
	{
		return Select::make( __( 'Variant Capitals' ), "common_{$this->common_key}_font_variant_cap" )
		             ->options( wpe_font_variant_capitals() )
		             ->responsive( true )
		             ->label_block( true );
	}

	public function weight ()
	{
		return Select::make( __( 'Weight' ), "common_{$this->common_key}_font_weight" )
		             ->options( wpe_font_weights() )
		             ->responsive( true )
		             ->label_block( true );
	}

	public function transform ()
	{
		return Select::make( __( 'Transform' ), "common_{$this->common_key}_font_cases" )
		             ->options( wpe_font_cases() )
		             ->responsive( true )
		             ->label_block( true );
	}

	public function style ()
	{
		return Select::make( __( 'Style' ), "common_{$this->common_key}_font_style" )
		             ->options( wpe_font_style() )
		             ->responsive( true )
		             ->label_block( true );
	}

	public function decoration ()
	{
		return Select::make( __( 'Decoration' ), "common_{$this->common_key}_font_decoration" )
		             ->options( wpe_font_decoration() )
		             ->responsive( true )
		             ->label_block( true );
	}

	public function line_height ()
	{
		return Slider::make( __( 'Line Height' ), "common_{$this->common_key}_font_line_height" )
		             ->size_unit( array_keys( wpe_style_unites() ) )
		             ->range( [
			             'px' => [
				             'min' => 1,
			             ],
			             'vw' => [
				             'min' => 0.1
			             ],
		             ] )
		             ->selector_value( 'line-height: {{SIZE}}{{UNIT}}' )
		             ->responsive( true );
	}

	public function letter_spacing ()
	{
		return Slider::make( __( 'Letter Spacing' ), "common_{$this->common_key}_font_letter_spacing" )
		             ->size_unit( array_keys( wpe_style_unites() ) )
		             ->range( [
			             'px' => [
				             'min' => 1,
			             ],
			             'vw' => [
				             'min' => 0.1
			             ],
		             ] )
		             ->selector_value( 'letter-spacing: {{SIZE}}{{UNIT}}' )
		             ->responsive( true );
	}


	public function word_spacing ()
	{
		return Slider::make( __( 'Word Spacing' ), "common_{$this->common_key}_font_word_spacing" )
		             ->size_unit( array_keys( wpe_style_unites() ) )
		             ->range( [
			             'px' => [
				             'min' => 1,
			             ],
			             'vw' => [
				             'min' => 0.1
			             ],
		             ] )
		             ->selector_value( 'word-spacing: {{SIZE}}{{UNIT}}' )
		             ->responsive( true );
	}

	public function text_stroke ()
	{
		return Slider::make( __( 'Text Stroke' ), "common_{$this->common_key}_font_text_stroke" )
		             ->size_unit( array_keys( wpe_style_unites() ) )
		             ->selector_value( '-webkit-text-stroke-width: {{SIZE}}{{UNIT}}; stroke-width: {{SIZE}}{{UNIT}};' )
		             ->responsive( true );
	}

	public function text_stroke_color ()
	{
		return Color::make( __( 'Text Stroke Color' ), "common_{$this->common_key}_font_text_stroke_color" )
		            ->global( [ 'default' => Global_Colors::COLOR_PRIMARY ] )
		            ->selector_value( '-webkit-text-stroke-color: {{VALUE}}; stroke: {{VALUE}};' );
	}

	public function text_shadow ()
	{
		return TextShadow::make( __( 'Text Shadow' ), "common_{$this->common_key}_font_shadow" )
		                 ->selector_value( 'text-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{COLOR}};' );
	}

	public function blend_mode ()
	{
		return Select::make( __( 'Blend Mode', 'wpessential' ), "common_{$this->common_key}_font_blend_mode" )
		             ->options( wpe_blend_mode() )
		             ->label_block( true )
		             ->selector_value( 'mix-blend-mode: {{VALUE}}' )
		             ->responsive( true );
	}
}
